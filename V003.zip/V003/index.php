<html>
  <head>
    <title>Dairin</title>
    <!-- CSS only -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100&display=swap" rel="stylesheet">
    <link href="css/fontawesome.css" rel="stylesheet">
    <link href="css/brands.css" rel="stylesheet">
    <link href="css/solid.css" rel="stylesheet">
    <link href="styles/custom.css" rel="stylesheet" crossorigin="anonymous">
  </head>
  <body>  
    <div class="container-fluid">
           <div>
            <img class="center-fit" style="float: right;" alt="" src="img/bg2.jpg" /> 
          </div> 
       
            <div class="row">
              <div class="col-lg-12" style="text-align: center; margin-top: 20%;"> 
                <h1 class="name"><b>DAIRIN JANAGAP</b></h1>

                <div class="row"> 
                  <div class="col-sm-12">
                    <hr/>
                    <p class="sub-info" style="font-size: 10px;">Software Engineer | IoT </p>
                    <p class="sub-info" style="font-size: 10px; margin-top: -13px;">Women Techmakers Ambassador</p>
                    <br>
                    <a style="padding-top:30px;"class="navbar-brand sub-info" href="https://www.facebook.com/dairinjan" target="_BLANK" title="Facebook"><i class="fab fa-facebook"></i></a> 
                    <a style="padding-top:30px;"class="navbar-brand sub-info" href="https://www.instagram.com/dairinjan" target="_BLANK" title="Instagram"><i class="fab fa-instagram"></i></a> 
                    <a style="padding-top:30px;"class="navbar-brand sub-info" href="https://www.linkedin.com/in/dairinjan/" target="_BLANK" title="LinkedIn"><i class="fab fa-linkedin"></i></a> 
                    <a style="padding-top:30px;"class="navbar-brand sub-info" href="https://www.womentechmakers.com/ambassadors/profiles/60b62d7cad362b66399b6230/dairin_janagap" target="_BLANK" title="Google Developers Group (WTM)"><i class="fab fa-google"></i></a> 

                  </div> 
                </div>
              </div> 
            </div> 
        </div> 
        <br><br><br><br>
  </body>

</html>
